# Windhawk mod symbol cache

A repository that generates an online cache for mod symbols in Windhawk. Having
the online cache enables mods to quickly get the required offsets without having
to download and parse the full symbol files.
